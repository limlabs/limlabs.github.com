// keyboardhook.cpp : Defines the exported functions for the DLL application.
//

#include <windows.h>

#define KEYBOARDHOOK_EXPORTS
#include "keyboardhook.h"

#pragma data_seg("KeyboardHookShared")
HWND g_hWnd = NULL; // Window handle
HHOOK g_hHook = NULL; // Hook handle
#pragma data_seg()

#pragma comment(linker,"/SECTION:KeyboardHookShared,RWS")

HMODULE g_hInstance = NULL;

BOOL APIENTRY DllMain( HMODULE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved)
{
	g_hInstance = hModule;
	return TRUE;
}

// Callback of hook
LRESULT CALLBACK KeyboardHookProc(int nCode, WPARAM wParam, LPARAM lParam)
{
	if((nCode == HC_ACTION)&&((DWORD)lParam&0x80000000)) 
	{ 
		if((GetKeyState(VK_CONTROL) < 0)&&(wParam == 'S'))
		{
			PostMessage(g_hWnd, WM_HOOK, 0, 0);
		}
	}
	return ::CallNextHookEx(g_hHook, nCode, wParam, lParam);
}

// Install hook
// This is an exported function
KEYBOARDHOOK_API BOOL InstallKeyboardHook(HWND hWnd)
{
	g_hWnd = hWnd;
	if(g_hHook == NULL)
	{ 
		g_hHook = ::SetWindowsHookEx(WH_KEYBOARD, KeyboardHookProc, g_hInstance, 0);
	}
	return g_hHook != NULL;
}

// Uninstall hook
// This is an exported function
KEYBOARDHOOK_API VOID UninstallKeyboardHook()
{
	if(g_hHook != NULL)
	{
		::UnhookWindowsHookEx(g_hHook);
		g_hHook = NULL;
	}
}
