#define IDI_TRAY    101  
#define ID_SETUP    40001  
#define ID_EXIT     40002 
