#ifndef WINVER 
#define WINVER 0x0501  
#endif 
#ifndef _WIN32_WINNT  
#define _WIN32_WINNT 0x0501 
#endif 
#ifndef _WIN32_WINDOWS
#define _WIN32_WINDOWS 0x0410  
#endif 
#ifndef _WIN32_IE
#define _WIN32_IE 0x0700  
#endif

#include <windows.h>
#include <winhttp.h>
#include <string>
#include <codecvt>
#include <string>
#include "resource.h"
#include "keyboardhook.h"

#pragma comment(lib, "winhttp.lib")
#pragma comment(lib, "keyboardhook.lib")

#define WM_TRAY (WM_USER + 100)
#define WM_TASKBAR_CREATED RegisterWindowMessage(TEXT("TaskbarCreated"))
#define APP_NAME	TEXT("ClipSender")

NOTIFYICONDATA nid;		//Tray property
HMENU hMenu;			//Tray menu

// convert UTF-8 string to wstring
std::wstring utf8_to_wstring (const std::string& str)
{
    std::wstring_convert<std::codecvt_utf8<wchar_t>> conv;
    return conv.from_bytes(str);
}

// convert wstring to UTF-8 string
std::string wstring_to_utf8 (const std::wstring& str)
{
    std::wstring_convert<std::codecvt_utf8<wchar_t>> conv;
    return conv.to_bytes(str);
}

//Initiate tray
void InitTray(HINSTANCE hInstance, HWND hWnd)
{
	nid.cbSize = sizeof(NOTIFYICONDATA);
	nid.hWnd = hWnd;
	nid.uID = IDI_TRAY;
	nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP | NIF_INFO;
	nid.uCallbackMessage = WM_TRAY;
	nid.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_TRAY));
	lstrcpy(nid.szTip, APP_NAME);

	hMenu = CreatePopupMenu();//Create tray menu
	AppendMenu(hMenu, MF_STRING, ID_SETUP, TEXT("Setup"));
	AppendMenu(hMenu, MF_STRING, ID_EXIT, TEXT("Quit"));

	Shell_NotifyIcon(NIM_ADD, &nid);
}

//Tray message tip
void ShowInfo(BOOL bSent, LPCTSTR info)
{
	
	std::wstring title = APP_NAME;
	title += TEXT(" sent");
	if(!bSent)
	{
		title += TEXT(" failed!");
		nid.dwInfoFlags = NIIF_ERROR;
	}
	else
	{
		title += TEXT(".");
		nid.dwInfoFlags = NIIF_INFO;
	}
	
	lstrcpy(nid.szInfoTitle, title.c_str());
	lstrcpy(nid.szInfo, info);
	nid.uTimeout = 5000;
	Shell_NotifyIcon(NIM_MODIFY, &nid);
}

BOOL HttpSend(const std::string& text)
{
	BOOL  bResults = FALSE;
	DWORD dwBytesWritten = 0;
	HINTERNET hSession = NULL, 
			  hConnect = NULL,
			  hRequest = NULL;

	// Use WinHttpOpen to obtain a session handle.
	hSession = WinHttpOpen( L"WinHttp Client/1.0",  
							WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
							WINHTTP_NO_PROXY_NAME, 
							WINHTTP_NO_PROXY_BYPASS, 
							0 );

	// Specify an HTTP server.
	if( hSession )
	hConnect = WinHttpConnect( hSession, L"127.0.0.1",
							   INTERNET_DEFAULT_HTTPS_PORT, 
							   0 );

	// Create an HTTP request handle.
	if( hConnect )
	hRequest = WinHttpOpenRequest( hConnect, L"POST", NULL, NULL, 
								   WINHTTP_NO_REFERER, 
								   WINHTTP_DEFAULT_ACCEPT_TYPES, 
								   0 );

	// Send a request.
	if( hRequest )
	bResults = WinHttpSendRequest( hRequest,
								   WINHTTP_NO_ADDITIONAL_HEADERS, 
								   0,
								   WINHTTP_NO_REQUEST_DATA, 
								   0, 
								   (DWORD)text.length(), 
								   0 );
	// Write body data
	if( bResults )
	bResults = WinHttpWriteData( hRequest, 
								 (LPCVOID)text.data(), 
								 (DWORD)text.length(), 
								 &dwBytesWritten);

	// Close any open handles.
	if( hRequest ) WinHttpCloseHandle( hRequest );
	if( hConnect ) WinHttpCloseHandle( hConnect );
	if( hSession ) WinHttpCloseHandle( hSession );

	return bResults;
}

// Target key operation is hooked
void OnHook(HWND hWnd)
{
	// Clipboard text in unicode
	std::wstring text;
	::OpenClipboard(hWnd); 
	HANDLE hClipMemory = ::GetClipboardData(CF_UNICODETEXT);
	if(hClipMemory != NULL)
	{
		wchar_t* pszText = static_cast<wchar_t*>(GlobalLock(hClipMemory));
		text = std::wstring(pszText);
		GlobalUnlock(hClipMemory); 
	}
	::CloseClipboard();

	if(text.empty())
	{
		ShowInfo(FALSE, TEXT("Clipboard is empty!"));
		return;
	}

	// Send text via http in utf-8
	std::string utf8_text = wstring_to_utf8(text);
	BOOL bSent = HttpSend(utf8_text);

	// Show tray info
	// Display the text in unicode
	ShowInfo(bSent, text.c_str());
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_CREATE:
		InitTray(((LPCREATESTRUCT)lParam)->hInstance, hWnd);
		InstallKeyboardHook(hWnd);
		break;
	case WM_DESTROY:
		UninstallKeyboardHook();
		Shell_NotifyIcon(NIM_DELETE, &nid);
		PostQuitMessage(0);
		break;
	case WM_TRAY:
		switch(lParam)
		{
		case WM_RBUTTONDOWN: // Right click
			{
				POINT pt; 
				GetCursorPos(&pt);
				SetForegroundWindow(hWnd);

				//Tack menu
				int cmd = TrackPopupMenu(hMenu, TPM_RETURNCMD, pt.x, pt.y, NULL, hWnd, NULL);
				if(cmd == ID_SETUP)
					MessageBox(hWnd, TEXT("Setup Window for UserName, Email, and so on."), APP_NAME, MB_OK);
				if(cmd == ID_EXIT) 
					PostMessage(hWnd, WM_DESTROY, NULL, NULL);
			}
			break;
		case WM_LBUTTONDOWN: // Left click
			break;
		case WM_LBUTTONDBLCLK: // Left double click
			MessageBox(hWnd, TEXT("Setup Window for UserName, Email, and so on."), APP_NAME, MB_OK);
			break;
		}
		break;
	case WM_HOOK:
		OnHook(hWnd);
		break;
	}
	if (uMsg == WM_TASKBAR_CREATED)
	{
		SendMessage(hWnd, WM_CREATE, wParam, lParam);
	}
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE /*hPrevInstance*/, LPSTR /*lpCmdLine*/, int iCmdShow)
{
	HWND handle = FindWindow(NULL, APP_NAME);
	if(handle != NULL)
	{
		MessageBox(NULL, TEXT("Application has been running already."), APP_NAME, MB_ICONERROR);
		return 0;
	}

	HWND hWnd;
	WNDCLASS wc = { 0 };
	wc.style = 0;
	wc.hIcon = NULL;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.lpfnWndProc = WndProc;
	wc.hbrBackground = NULL;
	wc.lpszMenuName = NULL;
	wc.lpszClassName = APP_NAME;
	wc.hCursor = NULL;

	if (!RegisterClass(&wc)) 
	{
		MessageBox(NULL, TEXT("Register window class failed. Need higher version system."), APP_NAME, MB_ICONERROR);
		return 0;
	}

	hWnd = CreateWindowEx(WS_EX_TOOLWINDOW, APP_NAME, APP_NAME, WS_POPUP, CW_USEDEFAULT,
		CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, NULL, NULL, hInstance, NULL);

	ShowWindow(hWnd, iCmdShow);
	UpdateWindow(hWnd);

	MSG msg;
	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}